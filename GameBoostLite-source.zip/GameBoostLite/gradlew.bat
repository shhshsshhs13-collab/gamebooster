@echo off
setlocal
set APP_HOME=%~dp0
set WRAPPER_DIR=%APP_HOME%gradle\wrapper
set WRAPPER_JAR=%WRAPPER_DIR%\gradle-wrapper.jar
set EXPECTED_SHA256=498495120a03b9a6ab5d155f5de3c8f0d986a449153702fb80fc80e134484f17
set WRAPPER_URL=https://raw.githubusercontent.com/gradle/gradle/v8.9.0/gradle/wrapper/gradle-wrapper.jar

if not exist "%WRAPPER_JAR%" (
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; Invoke-WebRequest -Uri '%WRAPPER_URL%' -OutFile '%WRAPPER_JAR%.tmp'; $actual=(Get-FileHash '%WRAPPER_JAR%.tmp' -Algorithm SHA256).Hash.ToLower(); if ($actual -ne '%EXPECTED_SHA256%') { Remove-Item '%WRAPPER_JAR%.tmp' -Force; throw 'Gradle Wrapper checksum mismatch' }; Move-Item '%WRAPPER_JAR%.tmp' '%WRAPPER_JAR%' -Force"
  if errorlevel 1 exit /b 1
)
java -classpath "%WRAPPER_JAR%" org.gradle.wrapper.GradleWrapperMain %*
endlocal
