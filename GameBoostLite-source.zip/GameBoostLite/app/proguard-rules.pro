# No custom rules are needed for the first prototype.
