package com.gameboostlite.app;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** Draggable in-game bubble. Tap it to start or open controls; panel provides pause/resume/stop. */
public class FloatingControlsService extends Service {
    private WindowManager windowManager;
    private WindowManager.LayoutParams windowParams;
    private LinearLayout root;
    private LinearLayout panel;
    private TextView bubble;
    private TextView pauseButton;
    private String state = "ARMED";
    private boolean paused;
    private boolean panelVisible;
    private boolean dragging;
    private float downRawX;
    private float downRawY;
    private int startX;
    private int startY;
    private int touchSlop = 8;
    private BroadcastReceiver stateReceiver;

    @Override
    public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        buildOverlay();
        try {
            windowParams = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT);
            windowParams.gravity = Gravity.TOP | Gravity.START;
            Prefs settings = new Prefs(this);
            windowParams.x = dp(settings.overlayXdp());
            windowParams.y = dp(settings.overlayYdp());
            windowManager.addView(root, windowParams);
        } catch (Exception e) {
            Toast.makeText(this, "Não foi possível mostrar o botão flutuante.", Toast.LENGTH_LONG).show();
            stopSelf();
            return;
        }

        stateReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                if (!ScreenCaptureService.ACTION_STATE.equals(intent.getAction())) return;
                state = intent.getStringExtra(ScreenCaptureService.EXTRA_STATE) == null ? "ARMED" : intent.getStringExtra(ScreenCaptureService.EXTRA_STATE);
                paused = intent.getBooleanExtra(ScreenCaptureService.EXTRA_PAUSED, false);
                if ("STOPPED".equals(state) || "STOPPING".equals(state)) {
                    stopSelf();
                    return;
                }
                updateBubble();
                updatePauseButton();
            }
        };
        IntentFilter filter = new IntentFilter(ScreenCaptureService.ACTION_STATE);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(stateReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(stateReceiver, filter);
        updateBubble();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_NOT_STICKY;
    }

    private void buildOverlay() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(3), dp(3), dp(3), dp(3));

        bubble = new TextView(this);
        bubble.setGravity(Gravity.CENTER);
        bubble.setText("REC");
        bubble.setContentDescription("GameBoost Lite: tocar para iniciar ou abrir controles de gravação");
        bubble.setTextColor(Color.rgb(8, 17, 11));
        bubble.setTextSize(12);
        bubble.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(bubble, new LinearLayout.LayoutParams(dp(56), dp(56)));
        bubble.setOnTouchListener(this::handleBubbleTouch);

        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(7), dp(7), dp(7), dp(7));
        panel.setBackground(round(Color.rgb(20, 27, 22), 16));
        panel.setVisibility(View.GONE);
        LinearLayout.LayoutParams panelLp = new LinearLayout.LayoutParams(dp(150), -2);
        panelLp.topMargin = dp(7);
        root.addView(panel, panelLp);

        pauseButton = actionButton("Ⅱ  Pausar", Color.rgb(43, 62, 48), Color.WHITE);
        pauseButton.setOnClickListener(v -> sendServiceAction(ScreenCaptureService.ACTION_TOGGLE_PAUSE));
        panel.addView(pauseButton, new LinearLayout.LayoutParams(-1, dp(42)));

        TextView stop = actionButton("■  Parar e salvar", Color.rgb(75, 34, 38), Color.rgb(255, 220, 221));
        LinearLayout.LayoutParams stopLp = new LinearLayout.LayoutParams(-1, dp(42));
        stopLp.topMargin = dp(6);
        panel.addView(stop, stopLp);
        stop.setOnClickListener(v -> sendServiceAction(ScreenCaptureService.ACTION_STOP));

        TextView tip = new TextView(this);
        tip.setText("Arraste para mover");
        tip.setTextColor(Color.rgb(158, 173, 162));
        tip.setTextSize(9);
        tip.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tipLp = new LinearLayout.LayoutParams(-1, -2);
        tipLp.topMargin = dp(5);
        panel.addView(tip, tipLp);
    }

    private boolean handleBubbleTouch(View view, MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                downRawX = event.getRawX();
                downRawY = event.getRawY();
                startX = windowParams.x;
                startY = windowParams.y;
                dragging = false;
                return true;
            case MotionEvent.ACTION_MOVE:
                float dx = event.getRawX() - downRawX;
                float dy = event.getRawY() - downRawY;
                if (Math.abs(dx) > dp(touchSlop) || Math.abs(dy) > dp(touchSlop)) dragging = true;
                if (dragging && windowParams != null && windowManager != null) {
                    windowParams.x = Math.max(0, Math.min(startX + (int) dx, getScreenWidth() - dp(62)));
                    windowParams.y = Math.max(0, Math.min(startY + (int) dy, getScreenHeight() - dp(62)));
                    try { windowManager.updateViewLayout(root, windowParams); } catch (Exception ignored) { }
                }
                return true;
            case MotionEvent.ACTION_UP:
                if (dragging && windowParams != null) {
                    float density = getResources().getDisplayMetrics().density;
                    new Prefs(this).setOverlayPositionDp(Math.round(windowParams.x / density), Math.round(windowParams.y / density));
                } else {
                    onBubbleTap();
                }
                return true;
            case MotionEvent.ACTION_CANCEL:
                return true;
        }
        return false;
    }

    private void onBubbleTap() {
        if ("ARMED".equals(state)) {
            sendServiceAction(ScreenCaptureService.ACTION_BEGIN_CAPTURE);
        } else if ("RECORDING".equals(state) || "PAUSED".equals(state)) {
            panelVisible = !panelVisible;
            panel.setVisibility(panelVisible ? View.VISIBLE : View.GONE);
            try { windowManager.updateViewLayout(root, windowParams); } catch (Exception ignored) { }
        }
    }

    private void updateBubble() {
        if (bubble == null) return;
        String text;
        int color;
        int textColor = Color.rgb(8, 17, 11);
        if ("ARMED".equals(state)) {
            text = "REC"; color = Color.rgb(104, 232, 156);
        } else if ("PAUSED".equals(state) || paused) {
            text = "▶"; color = Color.rgb(250, 195, 83);
        } else if ("RECORDING".equals(state)) {
            text = "●"; color = Color.rgb(248, 105, 115);
        } else {
            text = "REC"; color = Color.rgb(104, 232, 156);
        }
        if ("RECORDING".equals(state)) textColor = Color.WHITE;
        bubble.setText(text);
        bubble.setTextColor(textColor);
        String style = new Prefs(this).overlayStyle();
        int bubbleSize = "compact".equals(style) ? dp(46) : dp(56);
        ViewGroup.LayoutParams bubbleLp = bubble.getLayoutParams();
        if (bubbleLp != null && (bubbleLp.width != bubbleSize || bubbleLp.height != bubbleSize)) {
            bubbleLp.width = bubbleSize;
            bubbleLp.height = bubbleSize;
            bubble.setLayoutParams(bubbleLp);
        }
        GradientDrawable shape = round(color, 28);
        if ("bold".equals(style)) shape.setStroke(dp(3), Color.WHITE);
        bubble.setBackground(shape);
        bubble.setAlpha("semi".equals(style) ? 0.78f : 1f);
        updatePauseButton();
    }

    private void updatePauseButton() {
        if (pauseButton == null) return;
        pauseButton.setText(paused || "PAUSED".equals(state) ? "▶  Retomar" : "Ⅱ  Pausar");
    }

    private void sendServiceAction(String action) {
        Intent intent = new Intent(this, ScreenCaptureService.class);
        intent.setAction(action);
        startService(intent);
    }

    private TextView actionButton(String label, int background, int textColor) {
        TextView button = new TextView(this);
        button.setText(label);
        button.setTextColor(textColor);
        button.setTextSize(12);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setGravity(Gravity.CENTER);
        button.setBackground(round(background, 11));
        return button;
    }

    private GradientDrawable round(int color, int radius) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dp(radius));
        return bg;
    }

    private int getScreenWidth() {
        android.util.DisplayMetrics m = getResources().getDisplayMetrics();
        return m.widthPixels;
    }

    private int getScreenHeight() {
        android.util.DisplayMetrics m = getResources().getDisplayMetrics();
        return m.heightPixels;
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public void onDestroy() {
        try { if (stateReceiver != null) unregisterReceiver(stateReceiver); } catch (Exception ignored) { }
        try { if (root != null && windowManager != null) windowManager.removeView(root); } catch (Exception ignored) { }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
