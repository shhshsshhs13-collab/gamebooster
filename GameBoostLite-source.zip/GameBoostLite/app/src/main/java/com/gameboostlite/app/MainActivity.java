package com.gameboostlite.app;

import android.Manifest;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.Context;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.BatteryManager;
import android.os.Environment;
import android.database.Cursor;
import android.content.ContentUris;
import android.provider.MediaStore;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.io.File;

public class MainActivity extends Activity {
    private static final int REQ_OVERLAY = 101;
    private static final int REQ_PROJECTION = 102;
    private static final int REQ_AUDIO = 103;
    private static final int REQ_STORAGE = 104;

    private static final int BG = Color.rgb(13, 17, 16);
    private static final int SURFACE = Color.rgb(23, 29, 25);
    private static final int SURFACE_2 = Color.rgb(31, 40, 33);
    private static final int GREEN = Color.rgb(104, 232, 156);
    private static final int TEXT = Color.rgb(241, 247, 242);
    private static final int MUTED = Color.rgb(158, 173, 162);
    private static final int RED = Color.rgb(248, 105, 115);

    private Prefs prefs;
    private FrameLayout content;
    private LinearLayout nav;
    private String currentTab = "inicio";
    private boolean pendingStart;
    private boolean waitingForStorage;
    private boolean waitingForAudio;
    private BroadcastReceiver captureStateReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = new Prefs(this);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        buildShell();
        showTab(currentTab);
        captureStateReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                if (ScreenCaptureService.ACTION_STATE.equals(intent.getAction())) showTab(currentTab);
            }
        };
        IntentFilter stateFilter = new IntentFilter(ScreenCaptureService.ACTION_STATE);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(captureStateReceiver, stateFilter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(captureStateReceiver, stateFilter);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (content != null) showTab(currentTab);
    }

    @Override
    protected void onDestroy() {
        try { if (captureStateReceiver != null) unregisterReceiver(captureStateReceiver); } catch (Exception ignored) { }
        super.onDestroy();
    }

    private void buildShell() {
        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);
        shell.setBackgroundColor(BG);
        shell.setOnApplyWindowInsetsListener((view, insets) -> {
            view.setPadding(0, insets.getSystemWindowInsetTop(), 0, insets.getSystemWindowInsetBottom());
            return insets.consumeSystemWindowInsets();
        });

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(20), dp(15), dp(20), dp(12));
        header.setOrientation(LinearLayout.HORIZONTAL);

        TextView brandIcon = new TextView(this);
        brandIcon.setText("G");
        brandIcon.setTextColor(BG);
        brandIcon.setTextSize(21);
        brandIcon.setTypeface(Typeface.DEFAULT_BOLD);
        brandIcon.setGravity(Gravity.CENTER);
        brandIcon.setBackground(round(GREEN, 15));
        header.addView(brandIcon, new LinearLayout.LayoutParams(dp(42), dp(42)));

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.setPadding(dp(11), 0, 0, 0);
        TextView title = text("GameBoost Lite", 18, TEXT, true);
        TextView subtitle = text("CAPTURE • GAME TOOLS", 10, MUTED, true);
        titles.addView(title);
        titles.addView(subtitle);
        header.addView(titles, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));

        TextView status = text("BETA", 10, GREEN, true);
        status.setPadding(dp(10), dp(6), dp(10), dp(6));
        status.setBackground(round(SURFACE_2, 30));
        header.addView(status);
        shell.addView(header, new LinearLayout.LayoutParams(-1, -2));

        content = new FrameLayout(this);
        shell.addView(content, new LinearLayout.LayoutParams(-1, 0, 1));

        nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setBackgroundColor(Color.rgb(16, 21, 18));
        nav.setPadding(dp(5), dp(6), dp(5), dp(7));
        shell.addView(nav, new LinearLayout.LayoutParams(-1, -2));
        setContentView(shell);
        buildNav();
    }

    private void buildNav() {
        nav.removeAllViews();
        addNavItem("⌂", "Início", "inicio");
        addNavItem("◉", "Gravador", "gravador");
        addNavItem("▣", "Jogos", "jogos");
        addNavItem("⚙", "Config.", "config");
    }

    private void addNavItem(String icon, String label, String tab) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER);
        item.setPadding(0, dp(7), 0, dp(4));
        TextView symbol = text(icon, 18, currentTab.equals(tab) ? GREEN : MUTED, true);
        TextView caption = text(label, 10, currentTab.equals(tab) ? TEXT : MUTED, currentTab.equals(tab));
        item.addView(symbol);
        item.addView(caption);
        item.setOnClickListener(v -> showTab(tab));
        nav.addView(item, new LinearLayout.LayoutParams(0, -2, 1));
    }

    private void showTab(String tab) {
        currentTab = tab;
        buildNav();
        content.removeAllViews();
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(18), dp(12), dp(18), dp(24));
        scroll.addView(page);
        content.addView(scroll);

        switch (tab) {
            case "gravador": showRecorderTab(page); break;
            case "jogos": showGamesTab(page); break;
            case "config": showSettingsTab(page); break;
            default: showHomeTab(page); break;
        }
    }

    private void showHomeTab(LinearLayout page) {
        addText(page, "JOGUE. CAPTURE. COMPARTILHE.", 11, GREEN, true, 0, 7);
        addText(page, "Seu jogo.\nSua captura.", 32, TEXT, true, 0, 8);
        addText(page, "Ferramentas leves para gravar partidas e preparar o celular para jogar.", 14, MUTED, false, 0, 18);

        LinearLayout hero = card(page);
        addText(hero, "GRAVADOR DE TELA", 10, GREEN, true, 0, 8);
        addText(hero, ScreenCaptureService.isRecording() ? "Gravação em andamento" : (ScreenCaptureService.isArmed() ? "Botão flutuante pronto" : "Pronto para sua próxima partida"), 20, TEXT, true, 0, 6);
        addText(hero, prefs.resolution() + " • " + prefs.fps() + " FPS • áudio configurável", 12, MUTED, false, 0, 15);
        addButton(hero, ScreenCaptureService.isArmed() ? "Abrir controles de gravação" : "Preparar gravação", true, () -> {
            if (ScreenCaptureService.isArmed()) {
                showInfo("Botão flutuante ativo", ScreenCaptureService.isRecording() ? "A gravação está ativa. Toque no botão flutuante para abrir os controles de pausar e parar." : "Saia para o Free Fire e toque em REC no botão flutuante para começar.");
            } else {
                beginRecordingSetup();
            }
        });
        addText(hero, "A gravação só começa quando você tocar no botão flutuante por cima do jogo.", 11, MUTED, false, 0, 0);

        addText(page, "ATALHOS", 11, MUTED, true, 0, 10);
        addFeature(page, "▣", "Gravador", "Resolução, FPS e áudio em um só lugar", () -> showTab("gravador"));
        addFeature(page, "⚙", "Configurações", "Personalize gravação e botão flutuante", () -> showTab("config"));
        addFeature(page, "♧", "Preparação para jogar", "Dicas seguras sem promessas falsas de FPS", () -> showTab("jogos"));
        addDeviceStatus(page);
        addText(page, "VERSÃO 0.1.0 • PRIMEIRO PROTÓTIPO", 10, MUTED, true, 0, 4);
    }

    private void showRecorderTab(LinearLayout page) {
        addText(page, "GRAVADOR", 11, GREEN, true, 0, 7);
        addText(page, "Capture o momento.", 27, TEXT, true, 0, 8);
        addText(page, "Defina as opções antes de entrar na partida. O botão flutuante controla a gravação sem precisar voltar para o app.", 13, MUTED, false, 0, 12);
        addText(page, "Ao autorizar a captura do Android, escolha gravar a tela inteira se essa opção aparecer. Assim a gravação poderá acompanhar o Free Fire.", 11, MUTED, false, 0, 16);

        LinearLayout summary = card(page);
        addText(summary, "CONFIGURAÇÃO ATUAL", 10, GREEN, true, 0, 8);
        addText(summary, prefs.resolution() + "  •  " + prefs.fps() + " FPS", 21, TEXT, true, 0, 5);
        addText(summary, audioLabel(prefs.audioMode()), 13, MUTED, false, 0, 5);
        addText(summary, "Os limites reais dependem do aparelho, do Android e das permissões do jogo.", 11, MUTED, false, 0, 12);
        addButton(summary, ScreenCaptureService.isArmed() ? (ScreenCaptureService.isRecording() ? "Gravação ativa — ver controles" : "Botão flutuante pronto") : "Preparar gravação", true, () -> {
            if (ScreenCaptureService.isArmed()) showInfo("Botão flutuante", ScreenCaptureService.isRecording() ? "Toque no botão flutuante durante a partida para abrir os controles." : "Abra o jogo e toque em REC para começar a gravar.");
            else beginRecordingSetup();
        });
        addButton(summary, "Abrir configurações", false, () -> showTab("config"));

        LinearLayout tip = card(page);
        addText(tip, "COMO USAR", 10, GREEN, true, 0, 7);
        addText(tip, "1. Escolha qualidade e áudio.\n2. Toque em Preparar gravação e autorize a captura.\n3. Abra o Free Fire.\n4. Toque em REC no botão flutuante para começar.\n5. Abra os controles flutuantes para pausar ou parar.", 13, TEXT, false, 0, 0);

        LinearLayout library = card(page);
        addText(library, "GRAVAÇÕES RECENTES", 10, GREEN, true, 0, 8);
        addRecordings(library, 5);
    }

    private void showGamesTab(LinearLayout page) {
        addText(page, "JOGOS", 11, GREEN, true, 0, 7);
        addText(page, "Preparação inteligente", 27, TEXT, true, 0, 8);
        addText(page, "O GameBoost Lite não altera recursos protegidos do sistema. Estas ferramentas ajudam a preparar o aparelho e escolher gravações que pesem menos.", 13, MUTED, false, 0, 15);

        addGameCard(page, "Free Fire", "FOCO PRINCIPAL", "Comece com 720p e 30 FPS. Se houver quedas de desempenho, teste 480p. Feche apps pesados e evite gravar enquanto o celular estiver muito quente.");
        addGameCard(page, "Minecraft", "MUNDO ABERTO", "Mundos grandes e addons podem aumentar o uso de memória. Faça testes curtos de gravação antes de gravar uma sessão longa.");
        addGameCard(page, "Roblox e outros", "PERFIL GERAL", "Cada jogo permite políticas de captura diferentes. O áudio interno pode não estar disponível se o jogo bloquear a captura.");

        LinearLayout note = card(page);
        addText(note, "O QUE O OTIMIZADOR FAZ", 10, GREEN, true, 0, 7);
        addText(note, "Oferece atalhos para ajustes do Android, boas práticas de bateria e recomendações de gravação. Não promete aumentar FPS nem consegue encerrar à força qualquer processo de outros apps.", 12, MUTED, false, 0, 0);
    }

    private void showSettingsTab(LinearLayout page) {
        addText(page, "CONFIGURAÇÕES", 11, GREEN, true, 0, 7);
        addText(page, "Do seu jeito.", 28, TEXT, true, 0, 8);
        addText(page, "Escolha a qualidade que combina com o seu aparelho. Se uma opção não for compatível, o Android ou o gravador pode recusá-la.", 13, MUTED, false, 0, 12);
        if (ScreenCaptureService.isArmed()) addText(page, "Uma sessão já está preparada. Encerre-a pela notificação do GameBoost Lite antes de alterar opções de áudio ou qualidade.", 11, GREEN, false, 0, 12);

        LinearLayout resolutionCard = card(page);
        addText(resolutionCard, "RESOLUÇÃO", 11, TEXT, true, 0, 5);
        addText(resolutionCard, "Padrão recomendado: 720p", 12, MUTED, false, 0, 10);
        List<Option> resolutions = Arrays.asList(
                new Option("144p", "Mínima"), new Option("240p", "Muito leve"), new Option("360p", "Leve"),
                new Option("480p", "Equilibrada"), new Option("720p", "Recomendada"), new Option("1080p", "Mais detalhe"));
        addOptions(resolutionCard, 3, resolutions, prefs.resolution(), selected -> {
            if (!canEditSettings()) return;
            prefs.setResolution(selected);
            showTab("config");
        });

        LinearLayout fpsCard = card(page);
        addText(fpsCard, "TAXA DE QUADROS", 11, TEXT, true, 0, 5);
        addText(fpsCard, "Mais FPS pode aumentar o uso de CPU, GPU e bateria.", 12, MUTED, false, 0, 10);
        addOptions(fpsCard, 3, Arrays.asList(new Option("24 FPS", "Mais leve"), new Option("30 FPS", "Padrão"), new Option("60 FPS", "Mais fluido")), prefs.fps() + " FPS", selected -> {
            if (!canEditSettings()) return;
            prefs.setFps(Integer.parseInt(selected.replace(" FPS", "")));
            showTab("config");
        });

        LinearLayout audioCard = card(page);
        addText(audioCard, "ÁUDIO DA GRAVAÇÃO", 11, TEXT, true, 0, 5);
        addText(audioCard, "Escolha se a gravação deve captar sua voz.", 12, MUTED, false, 0, 10);
        List<Option> audioOptions = Arrays.asList(
                new Option(Prefs.AUDIO_GAME, "Som do jogo", "Sem voz"),
                new Option(Prefs.AUDIO_GAME_MIC, "Jogo + mic", "Jogo e voz"),
                new Option(Prefs.AUDIO_MIC, "Só microfone", "Sua voz"),
                new Option(Prefs.AUDIO_NONE, "Sem áudio", "Vídeo mudo"));
        addOptions(audioCard, 2, audioOptions, prefs.audioMode(), selected -> {
            if (!canEditSettings()) return;
            prefs.setAudioMode(selected);
            showTab("config");
        });
        addText(audioCard, "O som interno exige Android 10+ e só funciona quando o jogo permite a captura. O microfone sempre depende da permissão do usuário.", 11, MUTED, false, 0, 0);

        LinearLayout overlayCard = card(page);
        addText(overlayCard, "BOTÃO FLUTUANTE", 11, TEXT, true, 0, 5);
        addText(overlayCard, "O botão pode ser arrastado. Toque nele durante a partida para abrir os controles.", 12, MUTED, false, 0, 10);
        addOptions(overlayCard, 3, Arrays.asList(new Option("semi", "Transparente"), new Option("compact", "Compacto"), new Option("bold", "Visível")), prefs.overlayStyle(), selected -> {
            if (!canEditSettings()) return;
            prefs.setOverlayStyle(selected);
            showTab("config");
        });

        LinearLayout safety = card(page);
        addText(safety, "PRIVACIDADE E CONTROLE", 11, GREEN, true, 0, 7);
        addText(safety, "A captura só começa depois da autorização do Android. Os vídeos são salvos no aparelho, em Filmes/GameBoostLite. O app não envia gravações para um servidor.", 12, MUTED, false, 0, 0);
    }

    private void addGameCard(LinearLayout page, String title, String badge, String desc) {
        LinearLayout card = card(page);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView glyph = text("▶", 20, GREEN, true);
        glyph.setGravity(Gravity.CENTER);
        glyph.setBackground(round(SURFACE_2, 14));
        row.addView(glyph, new LinearLayout.LayoutParams(dp(44), dp(44)));
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.VERTICAL);
        head.setPadding(dp(10), 0, 0, 0);
        head.addView(text(title, 17, TEXT, true));
        head.addView(text(badge, 10, GREEN, true));
        row.addView(head, new LinearLayout.LayoutParams(0, -2, 1));
        card.addView(row);
        addText(card, desc, 12, MUTED, false, 0, 0);
    }

    private void addFeature(LinearLayout page, String icon, String title, String subtitle, Runnable action) {
        LinearLayout feature = new LinearLayout(this);
        feature.setOrientation(LinearLayout.HORIZONTAL);
        feature.setGravity(Gravity.CENTER_VERTICAL);
        feature.setPadding(dp(14), dp(13), dp(14), dp(13));
        feature.setBackground(round(SURFACE, 17));
        TextView glyph = text(icon, 20, GREEN, true);
        glyph.setGravity(Gravity.CENTER);
        feature.addView(glyph, new LinearLayout.LayoutParams(dp(34), dp(34)));
        LinearLayout labels = new LinearLayout(this);
        labels.setOrientation(LinearLayout.VERTICAL);
        labels.setPadding(dp(10), 0, 0, 0);
        labels.addView(text(title, 14, TEXT, true));
        labels.addView(text(subtitle, 11, MUTED, false));
        feature.addView(labels, new LinearLayout.LayoutParams(0, -2, 1));
        feature.addView(text("›", 23, MUTED, false));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(8);
        page.addView(feature, lp);
        feature.setOnClickListener(v -> action.run());
    }

    private void addDeviceStatus(LinearLayout page) {
        LinearLayout card = card(page);
        addText(card, "ESTADO DO APARELHO", 10, GREEN, true, 0, 8);
        ActivityManager.MemoryInfo memory = new ActivityManager.MemoryInfo();
        ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        if (am != null) am.getMemoryInfo(memory);
        long freeGb = Environment.getDataDirectory().getUsableSpace() / (1024L * 1024L * 1024L);
        int battery = -1;
        try {
            Intent batteryIntent = registerReceiver(null, new android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (batteryIntent != null) {
                int level = batteryIntent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                int scale = batteryIntent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
                if (level >= 0 && scale > 0) battery = Math.round(100f * level / scale);
            }
        } catch (Exception ignored) { }
        String availableRam = String.format(Locale.getDefault(), "%.1f GB", memory.availMem / (1024d * 1024d * 1024d));
        String batteryText = battery >= 0 ? battery + "%" : "Indisponível";
        addMetric(card, "RAM disponível", availableRam, "Espaço livre", freeGb + " GB");
        addMetric(card, "Bateria", batteryText, "Recomendação", "Grave em 720p/30 FPS para começar");
        addText(card, "São leituras informativas do Android; não representam FPS nem temperatura da CPU.", 10, MUTED, false, 8, 10);
        addButton(card, "Configurações de bateria", false, () -> openSettingsIntent(new Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)));
        addButton(card, "Detalhes do GameBoost Lite", false, () -> openSettingsIntent(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()))));
    }

    private void addMetric(LinearLayout parent, String titleA, String valueA, String titleB, String valueB) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(5), 0, dp(5));
        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        left.addView(text(titleA, 10, MUTED, false));
        left.addView(text(valueA, 17, TEXT, true));
        LinearLayout right = new LinearLayout(this);
        right.setOrientation(LinearLayout.VERTICAL);
        right.setGravity(Gravity.END);
        right.addView(text(titleB, 10, MUTED, false));
        TextView rv = text(valueB, 13, TEXT, true);
        rv.setGravity(Gravity.END);
        right.addView(rv);
        row.addView(left, new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(right, new LinearLayout.LayoutParams(0, -2, 1));
        parent.addView(row, new LinearLayout.LayoutParams(-1, -2));
    }

    private void openSettingsIntent(Intent intent) {
        try { startActivity(intent); }
        catch (Exception e) {
            showInfo("Configuração não disponível", "Este fabricante não oferece essa tela de configuração neste aparelho.");
        }
    }

    private void addRecordings(LinearLayout parent, int maxItems) {
        int count = 0;
        if (Build.VERSION.SDK_INT >= 29) {
            String[] projection = new String[]{
                    MediaStore.Video.Media._ID,
                    MediaStore.Video.Media.DISPLAY_NAME,
                    MediaStore.Video.Media.DURATION,
                    MediaStore.Video.Media.SIZE,
                    MediaStore.Video.Media.DATE_ADDED,
                    MediaStore.Video.Media.RELATIVE_PATH
            };
            String relativePath = Environment.DIRECTORY_MOVIES + "/GameBoostLite/";
            try (Cursor cursor = getContentResolver().query(
                    MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                    projection,
                    MediaStore.Video.Media.RELATIVE_PATH + "=?",
                    new String[]{relativePath},
                    MediaStore.Video.Media.DATE_ADDED + " DESC")) {
                if (cursor != null) {
                    int idIndex = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID);
                    int nameIndex = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME);
                    int durationIndex = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION);
                    int sizeIndex = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE);
                    while (cursor.moveToNext() && count < maxItems) {
                        long id = cursor.getLong(idIndex);
                        String name = cursor.getString(nameIndex);
                        long durationMs = cursor.getLong(durationIndex);
                        long size = cursor.getLong(sizeIndex);
                        Uri uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id);
                        addRecordingRow(parent, name, formatDuration(durationMs) + " • " + formatSize(size), uri);
                        count++;
                    }
                }
            } catch (Exception ignored) { }
        } else {
            File legacyFolder = new File(new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "GameBoostLite"), "");
            File[] videos = legacyFolder.listFiles((dir, name) -> name.toLowerCase(Locale.ROOT).endsWith(".mp4"));
            if (videos != null) {
                Arrays.sort(videos, (a, b) -> Long.compare(b.lastModified(), a.lastModified()));
                for (File video : videos) {
                    if (count >= maxItems) break;
                    Uri videoUri = findLegacyMediaUri(video);
                    addRecordingRow(parent, video.getName(), formatSize(video.length()), videoUri);
                    count++;
                }
            }
        }
        if (count == 0) addText(parent, "Suas gravações aparecerão aqui depois de salvar o primeiro vídeo.", 12, MUTED, false, 0, 0);
    }

    private void addRecordingRow(LinearLayout parent, String name, String metadata, Uri uri) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(10), dp(10), dp(10), dp(10));
        row.setBackground(round(SURFACE_2, 12));
        LinearLayout labels = new LinearLayout(this);
        labels.setOrientation(LinearLayout.VERTICAL);
        labels.addView(text(name, 11, TEXT, true));
        labels.addView(text(metadata, 10, MUTED, false));
        row.addView(labels, new LinearLayout.LayoutParams(0, -2, 1));
        TextView open = text(uri == null ? "MP4" : "▶", 12, GREEN, true);
        open.setGravity(Gravity.CENTER);
        row.addView(open, new LinearLayout.LayoutParams(dp(35), dp(35)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(5);
        parent.addView(row, lp);
        row.setOnClickListener(v -> {
            if (uri == null) {
                showInfo("Vídeo salvo", "O vídeo está na pasta Filmes/GameBoostLite. Abra-o pelo aplicativo de Galeria do celular.");
                return;
            }
            try {
                Intent play = new Intent(Intent.ACTION_VIEW);
                play.setDataAndType(uri, "video/mp4");
                play.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(play);
            } catch (Exception e) {
                showInfo("Não foi possível abrir o vídeo", "Tente abrir o vídeo pelo app de Galeria do celular.");
            }
        });
    }

    private Uri findLegacyMediaUri(File video) {
        try (Cursor cursor = getContentResolver().query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                new String[]{MediaStore.Video.Media._ID},
                MediaStore.Video.Media.DATA + "=?",
                new String[]{video.getAbsolutePath()},
                null)) {
            if (cursor != null && cursor.moveToFirst()) {
                return ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cursor.getLong(0));
            }
        } catch (Exception ignored) { }
        return null;
    }

    private String formatDuration(long durationMs) {
        long seconds = Math.max(0, durationMs / 1000L);
        return String.format(Locale.getDefault(), "%d:%02d", seconds / 60, seconds % 60);
    }

    private String formatSize(long bytes) {
        if (bytes < 1024L * 1024L) return Math.max(1, bytes / 1024L) + " KB";
        return String.format(Locale.getDefault(), "%.1f MB", bytes / (1024d * 1024d));
    }

    private boolean canEditSettings() {
        if (ScreenCaptureService.isArmed()) {
            showInfo("Sessão de captura ativa", "Encerre a sessão pela notificação do GameBoost Lite e altere as opções antes de preparar a gravação novamente.");
            return false;
        }
        return true;
    }

    private void beginRecordingSetup() {
        pendingStart = true;
        continueStartSetup();
    }

    private void continueStartSetup() {
        if (!pendingStart) return;

        if (Build.VERSION.SDK_INT < 29 && prefs.usesInternalAudio()) {
            new AlertDialog.Builder(this)
                    .setTitle("Áudio interno indisponível")
                    .setMessage("A captura do som do jogo exige Android 10 ou superior. Neste aparelho, escolha gravar só o microfone ou sem áudio.")
                    .setPositiveButton("Usar só microfone", (d, w) -> {
                        prefs.setAudioMode(Prefs.AUDIO_MIC);
                        showTab("config");
                        continueStartSetup();
                    })
                    .setNeutralButton("Gravar sem áudio", (d, w) -> {
                        prefs.setAudioMode(Prefs.AUDIO_NONE);
                        showTab("config");
                        continueStartSetup();
                    })
                    .setNegativeButton("Cancelar", (d, w) -> pendingStart = false)
                    .show();
            return;
        }

        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            Intent overlay = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivityForResult(overlay, REQ_OVERLAY);
            return;
        }

        if (!Prefs.AUDIO_NONE.equals(prefs.audioMode()) && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            waitingForAudio = true;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
            return;
        }

        if (Build.VERSION.SDK_INT <= 28 && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            waitingForStorage = true;
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE);
            return;
        }

        pendingStart = false;
        MediaProjectionManager manager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        startActivityForResult(manager.createScreenCaptureIntent(), REQ_PROJECTION);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_OVERLAY) {
            if (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this)) continueStartSetup();
            else {
                pendingStart = false;
                toast("A permissão do botão flutuante não foi concedida.");
            }
            return;
        }
        if (requestCode == REQ_PROJECTION) {
            if (resultCode == RESULT_OK && data != null) {
                Intent service = new Intent(this, ScreenCaptureService.class);
                service.setAction(ScreenCaptureService.ACTION_ARM);
                service.putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode);
                service.putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data);
                try {
                    if (Build.VERSION.SDK_INT >= 26) startForegroundService(service); else startService(service);
                    toast("Pronto! Abra o jogo e toque em REC no botão flutuante.");
                    showTab("gravador");
                } catch (Exception e) {
                    showInfo("Não foi possível preparar a gravação", friendlyError(e));
                }
            } else {
                toast("Captura cancelada. Nada foi gravado.");
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_AUDIO) {
            waitingForAudio = false;
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) continueStartSetup();
            else {
                pendingStart = false;
                showInfo("Permissão necessária", "Escolha 'Sem áudio' nas configurações para gravar sem conceder acesso ao microfone/áudio.");
            }
        } else if (requestCode == REQ_STORAGE) {
            waitingForStorage = false;
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) continueStartSetup();
            else {
                pendingStart = false;
                showInfo("Permissão de armazenamento", "Nesta versão antiga do Android, o acesso ao armazenamento é usado para salvar o vídeo na pasta Filmes.");
            }
        }
    }

    private void sendCaptureAction(String action) {
        Intent intent = new Intent(this, ScreenCaptureService.class);
        intent.setAction(action);
        startService(intent);
    }

    private void showInfo(String title, String message) {
        new AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("Entendi", null).show();
    }

    private String friendlyError(Exception e) {
        String message = e.getMessage();
        return message == null ? "O Android não conseguiu iniciar a captura. Verifique as permissões e tente novamente." : message;
    }

    private String audioLabel(String mode) {
        if (Prefs.AUDIO_GAME_MIC.equals(mode)) return "Som do jogo + microfone";
        if (Prefs.AUDIO_MIC.equals(mode)) return "Som do microfone";
        if (Prefs.AUDIO_NONE.equals(mode)) return "Sem áudio";
        return "Som interno do jogo, sem microfone";
    }

    private LinearLayout card(LinearLayout parent) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(16), dp(16), dp(16));
        card.setBackground(round(SURFACE, 20));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(12);
        parent.addView(card, lp);
        return card;
    }

    private void addText(LinearLayout parent, String value, int size, int color, boolean bold, int top, int bottom) {
        TextView view = text(value, size, color, bold);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(top);
        lp.bottomMargin = dp(bottom);
        parent.addView(view, lp);
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setIncludeFontPadding(true);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private void addButton(LinearLayout parent, String label, boolean primary, Runnable action) {
        TextView button = text(label, 14, primary ? BG : TEXT, true);
        button.setGravity(Gravity.CENTER);
        button.setPadding(dp(14), dp(14), dp(14), dp(14));
        button.setBackground(round(primary ? GREEN : SURFACE_2, 15));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(7);
        lp.bottomMargin = dp(2);
        parent.addView(button, lp);
        button.setOnClickListener(v -> action.run());
    }

    private void addOptions(LinearLayout parent, int columns, List<Option> choices, String selected, java.util.function.Consumer<String> onSelect) {
        for (int start = 0; start < choices.size(); start += columns) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(-1, -2);
            rowParams.bottomMargin = dp(4);
            parent.addView(row, rowParams);
            for (int c = 0; c < columns; c++) {
                int index = start + c;
                if (index >= choices.size()) {
                    View spacer = new View(this);
                    row.addView(spacer, new LinearLayout.LayoutParams(0, dp(76), 1));
                    continue;
                }
                Option option = choices.get(index);
                boolean isSelected = option.value.equals(selected);
                LinearLayout button = new LinearLayout(this);
                button.setOrientation(LinearLayout.VERTICAL);
                button.setGravity(Gravity.CENTER_VERTICAL);
                button.setPadding(dp(8), dp(8), dp(8), dp(8));
                GradientDrawable bg = round(isSelected ? Color.rgb(33, 57, 42) : SURFACE_2, 13);
                bg.setStroke(dp(1), isSelected ? GREEN : Color.rgb(45, 56, 48));
                button.setBackground(bg);
                button.addView(text(option.title, 12, isSelected ? GREEN : TEXT, true));
                if (option.subtitle != null && !option.subtitle.isEmpty()) {
                    TextView subtitle = text(option.subtitle, 9, MUTED, false);
                    button.addView(subtitle);
                }
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(76), 1);
                lp.leftMargin = dp(3);
                lp.rightMargin = dp(3);
                row.addView(button, lp);
                button.setOnClickListener(v -> onSelect.accept(option.value));
            }
        }
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private GradientDrawable round(int color, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radius));
        return drawable;
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private static final class Option {
        final String value;
        final String title;
        final String subtitle;
        Option(String value, String title) { this(value, title, ""); }
        Option(String value, String title, String subtitle) { this.value = value; this.title = title; this.subtitle = subtitle; }
    }
}
