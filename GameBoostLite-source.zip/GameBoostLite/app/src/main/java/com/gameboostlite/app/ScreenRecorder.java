package com.gameboostlite.app;

import android.content.ContentValues;
import android.content.Context;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaCodec;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.media.MediaRecorder;
import android.media.projection.MediaProjection;
import android.media.AudioPlaybackCaptureConfiguration;
import android.os.Build;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.view.Display;
import android.view.Surface;
import android.util.DisplayMetrics;

import java.io.File;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.Date;
import java.util.Locale;
import java.util.Queue;

/**
 * First-party screen recorder: MediaProjection -> AVC surface encoder -> MP4 muxer.
 * On Android 10+, game playback audio is captured through the official playback-capture API
 * when the target game allows it. Microphone and playback audio are mixed into one AAC track.
 */
public final class ScreenRecorder {
    private static final String MIME_VIDEO = "video/avc";
    private static final String MIME_AUDIO = "audio/mp4a-latm";
    private static final int AUDIO_RATE = 44100;
    private static final int AUDIO_CHUNK = 1024;

    private final Context context;
    private final MediaProjection projection;
    private final Prefs prefs;
    private final String audioMode;
    private final boolean wantsAudio;
    private final boolean wantsGameAudio;
    private final boolean wantsMic;

    private MediaCodec videoEncoder;
    private MediaCodec audioEncoder;
    private Surface videoInputSurface;
    private VirtualDisplay virtualDisplay;
    private MediaMuxer muxer;
    private ParcelFileDescriptor outputDescriptor;
    private android.net.Uri mediaStoreUri;
    private File legacyOutputFile;
    private AudioRecord gameAudioRecord;
    private AudioRecord micAudioRecord;
    private Thread drainThread;
    private Thread audioInputThread;

    private volatile boolean recording;
    private volatile boolean paused;
    private volatile boolean stopRequested;
    private volatile boolean videoEos;
    private volatile boolean audioEos;
    private volatile boolean muxerStarted;
    private volatile boolean failed;
    private volatile boolean waitForKeyFrame;
    private volatile String failureMessage = "";

    private int width;
    private int height;
    private int videoTrack = -1;
    private int audioTrack = -1;
    private long totalPausedUs;
    private long pauseStartedUs;
    private long lastVideoPtsUs = -1;
    private long audioSamplesSubmitted;
    private long stopRequestedAtMs;
    private final Queue<PendingSample> pendingSamples = new ArrayDeque<>();

    public ScreenRecorder(Context context, MediaProjection projection, Prefs prefs) {
        this.context = context.getApplicationContext();
        this.projection = projection;
        this.prefs = prefs;
        this.audioMode = prefs.audioMode();
        this.wantsAudio = !Prefs.AUDIO_NONE.equals(audioMode);
        this.wantsGameAudio = Prefs.AUDIO_GAME.equals(audioMode) || Prefs.AUDIO_GAME_MIC.equals(audioMode);
        this.wantsMic = Prefs.AUDIO_MIC.equals(audioMode) || Prefs.AUDIO_GAME_MIC.equals(audioMode);
    }

    public synchronized void start() throws Exception {
        if (recording) return;
        if (wantsGameAudio && Build.VERSION.SDK_INT < 29) {
            throw new IllegalStateException("Som interno do jogo exige Android 10 ou superior.");
        }
        calculateCaptureSize();
        createOutput();
        try {
            prepareVideoEncoder();
            if (wantsAudio) prepareAudioEncoderAndSources();
            virtualDisplay = projection.createVirtualDisplay(
                    "GameBoostLite-Capture", width, height,
                    context.getResources().getDisplayMetrics().densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    videoInputSurface, null, null);
            if (virtualDisplay == null) throw new IllegalStateException("O Android não criou o display de captura.");
            recording = true;
            if (wantsAudio) {
                audioInputThread = new Thread(this::audioInputLoop, "GameBoost-AudioInput");
                audioInputThread.start();
            } else {
                audioEos = true;
            }
            drainThread = new Thread(this::drainLoop, "GameBoost-EncoderDrain");
            drainThread.start();
        } catch (Exception e) {
            failed = true;
            failureMessage = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
            releaseResources(false);
            throw e;
        }
    }

    public synchronized boolean togglePaused() {
        if (!recording || stopRequested) return false;
        if (!paused) {
            paused = true;
            pauseStartedUs = System.nanoTime() / 1000L;
        } else {
            long now = System.nanoTime() / 1000L;
            totalPausedUs += Math.max(0, now - pauseStartedUs);
            paused = false;
            // Dropped frames during pause may be references for later AVC frames. Ask for a keyframe
            // and discard inter-frames until the next keyframe is seen, preserving a decodable MP4.
            waitForKeyFrame = true;
            try {
                if (videoEncoder != null) {
                    android.os.Bundle params = new android.os.Bundle();
                    params.putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0);
                    videoEncoder.setParameters(params);
                }
            } catch (Exception ignored) { }
        }
        return paused;
    }

    public boolean isPaused() { return paused; }

    public void stop() {
        if (stopRequested) return;
        stopRequested = true;
        recording = false;
        stopRequestedAtMs = System.currentTimeMillis();
        if (gameAudioRecord != null) {
            try { gameAudioRecord.stop(); } catch (Exception ignored) { }
        }
        if (micAudioRecord != null) {
            try { micAudioRecord.stop(); } catch (Exception ignored) { }
        }
        if (audioInputThread != null && audioInputThread != Thread.currentThread()) {
            try { audioInputThread.join(1500); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        }
        try {
            if (videoEncoder != null) videoEncoder.signalEndOfInputStream();
        } catch (Exception ignored) { }
        if (drainThread != null && drainThread != Thread.currentThread()) {
            try { drainThread.join(7000); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        }
        if (drainThread == null) releaseResources(true);
    }

    private void calculateCaptureSize() {
        DisplayMetrics metrics = new DisplayMetrics();
        Display display = null;
        try {
            android.view.WindowManager wm = (android.view.WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
            if (wm != null) display = wm.getDefaultDisplay();
            if (display != null) display.getRealMetrics(metrics);
        } catch (Exception ignored) { }
        if (metrics.widthPixels <= 0 || metrics.heightPixels <= 0) metrics = context.getResources().getDisplayMetrics();

        int sourceW = Math.max(2, metrics.widthPixels);
        int sourceH = Math.max(2, metrics.heightPixels);
        int requestedH = prefs.resolutionHeight();
        int captureH = Math.min(requestedH, sourceH);
        float ratio = (float) sourceW / (float) sourceH;
        int captureW = Math.round(captureH * ratio);
        captureW = Math.max(2, captureW - (captureW % 2));
        captureH = Math.max(2, captureH - (captureH % 2));
        width = captureW;
        height = captureH;
    }

    private void createOutput() throws Exception {
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        String filename = "GameBoostLite_" + stamp + ".mp4";
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Video.Media.DISPLAY_NAME, filename);
            values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
            values.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/GameBoostLite");
            values.put(MediaStore.Video.Media.IS_PENDING, 1);
            mediaStoreUri = context.getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
            if (mediaStoreUri == null) throw new IllegalStateException("Não foi possível criar o arquivo de vídeo.");
            outputDescriptor = context.getContentResolver().openFileDescriptor(mediaStoreUri, "w");
            if (outputDescriptor == null) throw new IllegalStateException("Não foi possível abrir o arquivo de vídeo.");
            muxer = new MediaMuxer(outputDescriptor.getFileDescriptor(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
        } else {
            File movies = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES);
            File folder = new File(movies, "GameBoostLite");
            if (!folder.exists() && !folder.mkdirs()) throw new IllegalStateException("Não foi possível criar a pasta Filmes/GameBoostLite.");
            legacyOutputFile = new File(folder, filename);
            muxer = new MediaMuxer(legacyOutputFile.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
        }
    }

    private void prepareVideoEncoder() throws Exception {
        MediaFormat format = MediaFormat.createVideoFormat(MIME_VIDEO, width, height);
        format.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfoCompat.COLOR_FORMAT_SURFACE);
        format.setInteger(MediaFormat.KEY_BIT_RATE, calculateBitrate(prefs.resolutionHeight(), prefs.fps()));
        format.setInteger(MediaFormat.KEY_FRAME_RATE, prefs.fps());
        format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2);
        videoEncoder = MediaCodec.createEncoderByType(MIME_VIDEO);
        videoEncoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
        videoInputSurface = videoEncoder.createInputSurface();
        videoEncoder.start();
    }

    private int calculateBitrate(int resolutionHeight, int fps) {
        int base;
        switch (resolutionHeight) {
            case 144: base = 180_000; break;
            case 240: base = 320_000; break;
            case 360: base = 650_000; break;
            case 480: base = 1_100_000; break;
            case 1080: base = 5_000_000; break;
            case 720:
            default: base = 2_400_000; break;
        }
        if (fps == 24) base = (int) (base * 0.82f);
        if (fps == 60) base = (int) (base * 1.55f);
        return Math.min(8_000_000, Math.max(180_000, base));
    }

    private void prepareAudioEncoderAndSources() throws Exception {
        MediaFormat format = MediaFormat.createAudioFormat(MIME_AUDIO, AUDIO_RATE, 1);
        format.setInteger(MediaFormat.KEY_AAC_PROFILE, android.media.MediaCodecInfo.CodecProfileLevel.AACObjectLC);
        format.setInteger(MediaFormat.KEY_BIT_RATE, 128_000);
        format.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, AUDIO_CHUNK * 2);
        audioEncoder = MediaCodec.createEncoderByType(MIME_AUDIO);
        audioEncoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
        audioEncoder.start();

        int bufferSize = Math.max(AudioRecord.getMinBufferSize(AUDIO_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT), AUDIO_CHUNK * 4);
        AudioFormat inputFormat = new AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(AUDIO_RATE)
                .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                .build();

        if (wantsGameAudio) {
            if (Build.VERSION.SDK_INT < 29) throw new IllegalStateException("Captura de áudio interno exige Android 10+.");
            AudioPlaybackCaptureConfiguration playbackConfig = new AudioPlaybackCaptureConfiguration.Builder(projection)
                    .addMatchingUsage(AudioAttributes.USAGE_GAME)
                    .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                    .build();
            gameAudioRecord = new AudioRecord.Builder()
                    .setAudioFormat(inputFormat)
                    .setBufferSizeInBytes(bufferSize)
                    .setAudioPlaybackCaptureConfig(playbackConfig)
                    .build();
            if (gameAudioRecord.getState() != AudioRecord.STATE_INITIALIZED) throw new IllegalStateException("O áudio interno não pôde ser inicializado neste aparelho.");
            gameAudioRecord.startRecording();
        }

        if (wantsMic) {
            micAudioRecord = new AudioRecord(MediaRecorder.AudioSource.MIC, AUDIO_RATE,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufferSize);
            if (micAudioRecord.getState() != AudioRecord.STATE_INITIALIZED) throw new IllegalStateException("O microfone não pôde ser inicializado.");
            micAudioRecord.startRecording();
        }
    }

    private void audioInputLoop() {
        short[] gameSamples = new short[AUDIO_CHUNK];
        short[] micSamples = new short[AUDIO_CHUNK];
        short[] mixedSamples = new short[AUDIO_CHUNK];
        long nextPtsUs;
        try {
            while (recording && !stopRequested) {
                if (paused) {
                    discardAudioWhilePaused(gameSamples, micSamples);
                    sleepQuietly(20);
                    continue;
                }

                int gameCount = 0;
                int micCount = 0;
                if (gameAudioRecord != null && gameAudioRecord.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) {
                    gameCount = gameAudioRecord.read(gameSamples, 0, AUDIO_CHUNK, AudioRecord.READ_NON_BLOCKING);
                    if (gameCount < 0) gameCount = 0;
                }
                if (micAudioRecord != null && micAudioRecord.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) {
                    micCount = micAudioRecord.read(micSamples, 0, AUDIO_CHUNK, AudioRecord.READ_NON_BLOCKING);
                    if (micCount < 0) micCount = 0;
                }

                int inputIndex = audioEncoder.dequeueInputBuffer(10_000);
                if (inputIndex >= 0) {
                    ByteBuffer input = audioEncoder.getInputBuffer(inputIndex);
                    if (input == null) continue;
                    input.clear();
                    for (int i = 0; i < AUDIO_CHUNK; i++) {
                        int sample = 0;
                        if (wantsGameAudio && wantsMic) {
                            if (i < gameCount) sample += gameSamples[i] / 2;
                            if (i < micCount) sample += micSamples[i] / 2;
                        } else {
                            if (i < gameCount) sample += gameSamples[i];
                            if (i < micCount) sample += micSamples[i];
                        }
                        sample = Math.max(Short.MIN_VALUE, Math.min(Short.MAX_VALUE, sample));
                        mixedSamples[i] = (short) sample;
                        input.put((byte) (mixedSamples[i] & 0xff));
                        input.put((byte) ((mixedSamples[i] >> 8) & 0xff));
                    }
                    nextPtsUs = audioSamplesSubmitted * 1_000_000L / AUDIO_RATE;
                    audioEncoder.queueInputBuffer(inputIndex, 0, AUDIO_CHUNK * 2, nextPtsUs, 0);
                    audioSamplesSubmitted += AUDIO_CHUNK;
                }
                sleepQuietly(23);
            }
        } catch (Exception e) {
            failed = true;
            failureMessage = e.getMessage() == null ? "Falha na captura de áudio" : e.getMessage();
        } finally {
            try {
                if (audioEncoder != null) {
                    boolean queuedEos = false;
                    for (int attempt = 0; attempt < 20 && !queuedEos; attempt++) {
                        int eosInput = audioEncoder.dequeueInputBuffer(25_000);
                        if (eosInput >= 0) {
                            long pts = audioSamplesSubmitted * 1_000_000L / AUDIO_RATE;
                            audioEncoder.queueInputBuffer(eosInput, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                            queuedEos = true;
                        }
                    }
                }
            } catch (Exception ignored) { }
            stopAudioSources();
        }
    }

    private void discardAudioWhilePaused(short[] gameBuffer, short[] micBuffer) {
        try {
            if (gameAudioRecord != null && gameAudioRecord.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING)
                gameAudioRecord.read(gameBuffer, 0, gameBuffer.length, AudioRecord.READ_NON_BLOCKING);
        } catch (Exception ignored) { }
        try {
            if (micAudioRecord != null && micAudioRecord.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING)
                micAudioRecord.read(micBuffer, 0, micBuffer.length, AudioRecord.READ_NON_BLOCKING);
        } catch (Exception ignored) { }
    }

    private void drainLoop() {
        MediaCodec.BufferInfo videoInfo = new MediaCodec.BufferInfo();
        MediaCodec.BufferInfo audioInfo = new MediaCodec.BufferInfo();
        long startMs = System.currentTimeMillis();
        try {
            while (!videoEos || (wantsAudio && !audioEos)) {
                drainOne(videoEncoder, videoInfo, true);
                if (wantsAudio && audioEncoder != null) drainOne(audioEncoder, audioInfo, false);
                if (stopRequested && System.currentTimeMillis() - Math.max(startMs, stopRequestedAtMs) > 6500) break;
                sleepQuietly(4);
            }
            if (muxerStarted) flushPendingSamples();
        } catch (Exception e) {
            failed = true;
            failureMessage = e.getMessage() == null ? "Falha ao finalizar o vídeo" : e.getMessage();
        } finally {
            releaseResources(true);
        }
    }

    private void drainOne(MediaCodec codec, MediaCodec.BufferInfo info, boolean video) {
        if (codec == null) {
            if (video) videoEos = true; else audioEos = true;
            return;
        }
        try {
            int outputIndex;
            while ((outputIndex = codec.dequeueOutputBuffer(info, 0)) >= 0) {
                ByteBuffer encoded = codec.getOutputBuffer(outputIndex);
                if ((info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0;

                if (info.size > 0 && encoded != null) {
                    encoded.position(info.offset);
                    encoded.limit(info.offset + info.size);
                    byte[] bytes = new byte[info.size];
                    encoded.get(bytes);
                    long pts = info.presentationTimeUs;
                    boolean safeToWrite = true;
                    if (video) {
                        long pausedTime = totalPausedUs;
                        if (paused) pausedTime += Math.max(0, System.nanoTime() / 1000L - pauseStartedUs);
                        pts = Math.max(0, pts - pausedTime);
                        if (pts <= lastVideoPtsUs) pts = lastVideoPtsUs + 1;
                        lastVideoPtsUs = pts;
                        if (waitForKeyFrame) {
                            if ((info.flags & MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0) waitForKeyFrame = false;
                            else safeToWrite = false;
                        }
                    }
                    if (!paused && safeToWrite) {
                        PendingSample sample = new PendingSample(video, bytes, pts, info.flags);
                        if (muxerStarted) writeSample(sample); else pendingSamples.add(sample);
                    }
                }
                boolean eos = (info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;
                codec.releaseOutputBuffer(outputIndex, false);
                if (eos) {
                    if (video) videoEos = true; else audioEos = true;
                    break;
                }
            }

            if (outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                if (video && videoTrack < 0) videoTrack = muxer.addTrack(codec.getOutputFormat());
                if (!video && audioTrack < 0) audioTrack = muxer.addTrack(codec.getOutputFormat());
                startMuxerIfReady();
            }
        } catch (Exception e) {
            failed = true;
            failureMessage = e.getMessage() == null ? "Falha ao codificar o vídeo" : e.getMessage();
            if (video) videoEos = true; else audioEos = true;
        }
    }

    private void startMuxerIfReady() throws Exception {
        boolean ready = videoTrack >= 0 && (!wantsAudio || audioTrack >= 0);
        if (ready && !muxerStarted) {
            muxer.start();
            muxerStarted = true;
            flushPendingSamples();
        }
    }

    private void flushPendingSamples() {
        if (!muxerStarted) return;
        while (!pendingSamples.isEmpty()) writeSample(pendingSamples.poll());
    }

    private void writeSample(PendingSample sample) {
        if (sample == null || !muxerStarted || paused) return;
        int track = sample.video ? videoTrack : audioTrack;
        if (track < 0 || sample.data.length == 0) return;
        try {
            ByteBuffer buffer = ByteBuffer.wrap(sample.data);
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            info.set(0, sample.data.length, sample.ptsUs, sample.flags & ~MediaCodec.BUFFER_FLAG_END_OF_STREAM);
            muxer.writeSampleData(track, buffer, info);
        } catch (Exception e) {
            failed = true;
            failureMessage = e.getMessage() == null ? "Falha ao salvar o vídeo" : e.getMessage();
        }
    }

    private synchronized void releaseResources(boolean finalizeFile) {
        try { if (virtualDisplay != null) { virtualDisplay.release(); virtualDisplay = null; } } catch (Exception ignored) { }
        try { if (videoInputSurface != null) { videoInputSurface.release(); videoInputSurface = null; } } catch (Exception ignored) { }
        try { if (gameAudioRecord != null) { gameAudioRecord.release(); gameAudioRecord = null; } } catch (Exception ignored) { }
        try { if (micAudioRecord != null) { micAudioRecord.release(); micAudioRecord = null; } } catch (Exception ignored) { }
        try { if (audioEncoder != null) { audioEncoder.stop(); audioEncoder.release(); audioEncoder = null; } } catch (Exception ignored) { }
        try { if (videoEncoder != null) { videoEncoder.stop(); videoEncoder.release(); videoEncoder = null; } } catch (Exception ignored) { }

        boolean hasOutput = false;
        try {
            if (muxer != null) {
                if (muxerStarted) {
                    muxer.stop();
                    hasOutput = true;
                }
                muxer.release();
                muxer = null;
            }
        } catch (Exception ignored) { }
        muxerStarted = false;
        try { if (outputDescriptor != null) { outputDescriptor.close(); outputDescriptor = null; } } catch (Exception ignored) { }

        if (Build.VERSION.SDK_INT >= 29 && mediaStoreUri != null) {
            try {
                if (finalizeFile && hasOutput) {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Video.Media.IS_PENDING, 0);
                    context.getContentResolver().update(mediaStoreUri, values, null, null);
                } else {
                    context.getContentResolver().delete(mediaStoreUri, null, null);
                }
            } catch (Exception ignored) { }
            mediaStoreUri = null;
        } else if (legacyOutputFile != null && finalizeFile && hasOutput) {
            android.media.MediaScannerConnection.scanFile(context,
                    new String[]{legacyOutputFile.getAbsolutePath()}, new String[]{"video/mp4"}, null);
        } else if (legacyOutputFile != null && (!finalizeFile || !hasOutput)) {
            //noinspection ResultOfMethodCallIgnored
            legacyOutputFile.delete();
        }
        pendingSamples.clear();
        recording = false;
    }

    private void stopAudioSources() {
        try { if (gameAudioRecord != null && gameAudioRecord.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) gameAudioRecord.stop(); } catch (Exception ignored) { }
        try { if (micAudioRecord != null && micAudioRecord.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) micAudioRecord.stop(); } catch (Exception ignored) { }
    }

    private void sleepQuietly(long millis) {
        try { Thread.sleep(millis); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }

    private static final class PendingSample {
        final boolean video;
        final byte[] data;
        final long ptsUs;
        final int flags;
        PendingSample(boolean video, byte[] data, long ptsUs, int flags) {
            this.video = video; this.data = data; this.ptsUs = ptsUs; this.flags = flags;
        }
    }

    private static final class MediaCodecInfoCompat {
        static final int COLOR_FORMAT_SURFACE = android.media.MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface;
    }
}
