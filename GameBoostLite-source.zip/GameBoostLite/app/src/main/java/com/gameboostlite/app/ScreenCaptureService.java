package com.gameboostlite.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.widget.Toast;

/** Owns the user's MediaProjection session and recording engine. */
public class ScreenCaptureService extends Service {
    public static final String ACTION_ARM = "com.gameboostlite.app.action.ARM";
    public static final String ACTION_BEGIN_CAPTURE = "com.gameboostlite.app.action.BEGIN_CAPTURE";
    public static final String ACTION_TOGGLE_PAUSE = "com.gameboostlite.app.action.TOGGLE_PAUSE";
    public static final String ACTION_STOP = "com.gameboostlite.app.action.STOP";
    public static final String ACTION_STATE = "com.gameboostlite.app.action.STATE";
    public static final String EXTRA_RESULT_CODE = "projection_result_code";
    public static final String EXTRA_RESULT_DATA = "projection_result_data";
    public static final String EXTRA_STATE = "capture_state";
    public static final String EXTRA_PAUSED = "capture_paused";

    private static final String CHANNEL_ID = "gameboost_capture";
    private static final int NOTIFICATION_ID = 45;
    public static volatile boolean armed = false;
    public static volatile boolean recording = false;

    private MediaProjection projection;
    private ScreenRecorder recorder;
    private boolean stopping;

    public static boolean isArmed() { return armed; }
    public static boolean isRecording() { return recording; }

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || intent.getAction() == null) return START_NOT_STICKY;
        String action = intent.getAction();
        if (ACTION_ARM.equals(action)) {
            armProjection(intent);
        } else if (ACTION_BEGIN_CAPTURE.equals(action)) {
            beginCapture();
        } else if (ACTION_TOGGLE_PAUSE.equals(action)) {
            togglePause();
        } else if (ACTION_STOP.equals(action)) {
            stopSession(true);
        }
        return START_NOT_STICKY;
    }

    private void armProjection(Intent intent) {
        if (armed || projection != null) {
            sendState("ARMED", false);
            return;
        }
        int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0);
        Intent resultData = getResultData(intent);
        if (resultData == null) {
            Toast.makeText(this, "Não foi possível iniciar a captura. Autorize a tela novamente.", Toast.LENGTH_LONG).show();
            stopSelf();
            return;
        }

        try {
            Prefs prefs = new Prefs(this);
            int foregroundTypes = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION;
            if (Build.VERSION.SDK_INT >= 29 && prefs.usesMicrophone()) {
                foregroundTypes |= ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE;
            }
            Notification notification = buildNotification("Pronto para gravar", "Toque em REC no botão flutuante para começar.");
            if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION_ID, notification, foregroundTypes);
            else startForeground(NOTIFICATION_ID, notification);

            MediaProjectionManager manager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            projection = manager.getMediaProjection(resultCode, resultData);
            if (projection == null) throw new IllegalStateException("O Android não disponibilizou a captura de tela.");
            projection.registerCallback(new MediaProjection.Callback() {
                @Override public void onStop() {
                    if (!stopping) stopSession(false);
                }
            }, new Handler(Looper.getMainLooper()));

            armed = true;
            recording = false;
            Intent overlay = new Intent(this, FloatingControlsService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundServiceIfNeeded(overlay); else startService(overlay);
            updateNotification("Pronto para gravar", "Abra o jogo e toque em REC no botão flutuante.");
            sendState("ARMED", false);
        } catch (Exception e) {
            Toast.makeText(this, "Erro ao preparar captura: " + safeMessage(e), Toast.LENGTH_LONG).show();
            stopSession(false);
        }
    }

    private Intent getResultData(Intent intent) {
        if (Build.VERSION.SDK_INT >= 33) return intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent.class);
        //noinspection deprecation
        return intent.getParcelableExtra(EXTRA_RESULT_DATA);
    }

    private void beginCapture() {
        if (stopping || !armed || projection == null || recording) return;
        try {
            recorder = new ScreenRecorder(this, projection, new Prefs(this));
            recorder.start();
            recording = true;
            updateNotification("Gravando sua tela", "Use o botão flutuante para pausar ou parar.");
            sendState("RECORDING", false);
        } catch (Exception e) {
            Toast.makeText(this, "Não foi possível gravar: " + safeMessage(e), Toast.LENGTH_LONG).show();
            stopSession(false);
        }
    }

    private void togglePause() {
        if (!recording || recorder == null || stopping) return;
        boolean paused = recorder.togglePaused();
        updateNotification(paused ? "Gravação pausada" : "Gravando sua tela", paused ? "Toque em retomar para continuar." : "Use o botão flutuante para pausar ou parar.");
        sendState(paused ? "PAUSED" : "RECORDING", paused);
    }

    private void stopSession(boolean userInitiated) {
        if (stopping) return;
        stopping = true;
        armed = false;
        recording = false;
        sendState("STOPPING", false);
        new Thread(() -> {
            try {
                if (recorder != null) {
                    recorder.stop();
                    recorder = null;
                }
            } catch (Exception ignored) { }
            try {
                if (projection != null) {
                    projection.stop();
                    projection = null;
                }
            } catch (Exception ignored) { }
            try { stopService(new Intent(this, FloatingControlsService.class)); } catch (Exception ignored) { }
            sendState("STOPPED", false);
            if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE); else stopForeground(true);
            stopSelf();
            stopping = false;
        }, "GameBoost-stop").start();
    }

    private void sendState(String state, boolean paused) {
        Intent intent = new Intent(ACTION_STATE);
        intent.setPackage(getPackageName());
        intent.putExtra(EXTRA_STATE, state);
        intent.putExtra(EXTRA_PAUSED, paused);
        sendBroadcast(intent);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "GameBoost Lite — gravação", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Notificação permanente durante a sessão de captura de tela.");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification(String title, String text) {
        Intent stop = new Intent(this, ScreenCaptureService.class);
        stop.setAction(ACTION_STOP);
        PendingIntent stopPending = PendingIntent.getService(this, 6, stop, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        builder.setSmallIcon(android.R.drawable.presence_video_online)
                .setContentTitle(title)
                .setContentText(text)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .addAction(android.R.drawable.ic_media_pause, "Encerrar", stopPending);
        return builder.build();
    }

    private void updateNotification(String title, String text) {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager != null) manager.notify(NOTIFICATION_ID, buildNotification(title, text));
    }

    private void startForegroundServiceIfNeeded(Intent intent) {
        // This service is only a UI overlay; the actual foreground work is owned by this capture service.
        startService(intent);
    }

    private String safeMessage(Exception e) {
        return e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
    }

    @Override
    public void onDestroy() {
        if (!stopping && (projection != null || recorder != null)) stopSession(false);
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
