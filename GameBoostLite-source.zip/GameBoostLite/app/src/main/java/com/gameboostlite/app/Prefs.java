package com.gameboostlite.app;

import android.content.Context;
import android.content.SharedPreferences;

/** Small settings wrapper shared by the activity, floating UI and recorder. */
public final class Prefs {
    private static final String FILE = "gameboost_settings";
    public static final String AUDIO_GAME = "game";
    public static final String AUDIO_GAME_MIC = "game_mic";
    public static final String AUDIO_MIC = "mic";
    public static final String AUDIO_NONE = "none";

    private final SharedPreferences prefs;

    public Prefs(Context context) {
        prefs = context.getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    public String resolution() { return prefs.getString("resolution", "720p"); }
    public void setResolution(String value) { prefs.edit().putString("resolution", value).apply(); }

    public int fps() { return prefs.getInt("fps", 30); }
    public void setFps(int value) { prefs.edit().putInt("fps", value).apply(); }

    public String audioMode() { return prefs.getString("audio_mode", AUDIO_GAME); }
    public void setAudioMode(String value) { prefs.edit().putString("audio_mode", value).apply(); }

    public String overlayStyle() { return prefs.getString("overlay_style", "semi"); }
    public void setOverlayStyle(String value) { prefs.edit().putString("overlay_style", value).apply(); }

    public int overlayXdp() { return prefs.getInt("overlay_x_dp", 14); }
    public int overlayYdp() { return prefs.getInt("overlay_y_dp", 230); }
    public void setOverlayPositionDp(int x, int y) {
        prefs.edit().putInt("overlay_x_dp", Math.max(0, x)).putInt("overlay_y_dp", Math.max(0, y)).apply();
    }

    public int resolutionHeight() {
        switch (resolution()) {
            case "144p": return 144;
            case "240p": return 240;
            case "360p": return 360;
            case "480p": return 480;
            case "1080p": return 1080;
            case "720p":
            default: return 720;
        }
    }

    public boolean usesInternalAudio() {
        return AUDIO_GAME.equals(audioMode()) || AUDIO_GAME_MIC.equals(audioMode());
    }

    public boolean usesMicrophone() {
        return AUDIO_MIC.equals(audioMode()) || AUDIO_GAME_MIC.equals(audioMode());
    }
}
