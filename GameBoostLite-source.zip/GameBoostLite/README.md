# GameBoost Lite — protótipo Android 0.1.0

Projeto nativo Android (Java) para um aplicativo público distribuído por APK. O foco é gravar partidas de Free Fire e outros jogos, com painel simples, opções de áudio/qualidade e botão flutuante.

> **Estado honesto:** os arquivos-fonte estão preparados, mas este ambiente não tem Android SDK nem Gradle instalados. Por isso, não foi possível compilar nem testar um APK neste ambiente. O projeto ainda precisa ser sincronizado, compilado e testado em Android Studio e em aparelhos reais antes de ser distribuído publicamente.

## Funcionalidades implementadas no código

- Interface escura com acentos verdes e navegação Início / Gravador / Jogos / Configurações.
- Resolução selecionável: 144p, 240p, 360p, 480p, 720p e 1080p. Padrão: 720p.
- FPS selecionável: 24, 30 ou 60. Padrão: 30 FPS.
- Áudio selecionável: som interno do jogo sem microfone, som do jogo + microfone, somente microfone ou sem áudio.
- Captura de tela por `MediaProjection`, codificação de vídeo AVC e arquivo MP4.
- Captura de áudio de reprodução por `AudioPlaybackCapture` no Android 10+ quando o jogo permite; o microfone pode ser misturado na mesma faixa AAC.
- Botão flutuante arrastável, controles para iniciar, pausar/retomar e parar/salvar.
- Opções de aparência do botão: semitransparente, compacto e com contorno mais visível.
- Salva gravações em `Filmes/GameBoostLite` e mostra vídeos recentes dentro do app.
- Mostra memória RAM disponível, espaço livre e nível de bateria, além de atalhos para configurações do Android.
- O app não tem permissão de internet e não envia os vídeos para um servidor.

## Requisitos de desenvolvimento

- Android Studio recente, com suporte a Android Gradle Plugin 8.7.3.
- JDK 17.
- Android SDK Platform 35 e Build Tools instaladas pelo SDK Manager.
- Internet no primeiro build para baixar o Gradle Wrapper e dependências oficiais.
- O aparelho de teste deve permitir sobreposição de tela e captura de tela.

## Como compilar o APK de teste

1. Extraia o ZIP e abra a pasta `GameBoostLite` no Android Studio usando **Open**.
2. Instale a plataforma Android SDK 35 se o Android Studio solicitar e aguarde o Gradle Sync.
3. Selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)**, ou use o terminal da pasta do projeto:

```bash
./gradlew :app:assembleDebug
```

No Windows, use `gradlew.bat :app:assembleDebug`. O script baixa o Gradle Wrapper oficial na primeira execução e verifica o checksum antes de executá-lo. O checksum da distribuição Gradle também está configurado.
4. O APK de debug, assinado com a chave de depuração, deverá aparecer em `app/build/outputs/apk/debug/app-debug.apk`.
5. Instale no aparelho de teste e conceda as permissões somente após ler os diálogos do Android.

O ambiente em que este projeto foi preparado não tinha Android SDK nem Gradle disponíveis, portanto a compilação precisa ocorrer em uma máquina de desenvolvimento com internet e Android SDK instalado. Para distribuição pública, configure uma chave de assinatura de release própria e mantenha essa chave privada; não publique o build de debug.

## Fluxo de uso previsto

1. Abra GameBoost Lite e escolha resolução, FPS e áudio.
2. Toque em **Preparar gravação**.
3. Autorize a sobreposição e a captura de tela. Se o Android oferecer a escolha entre capturar um app e a tela inteira, escolha **tela inteira** para a captura poder acompanhar o Free Fire ao alternar de app.
4. Abra o jogo. Toque no botão flutuante verde **REC** para começar.
5. Toque no botão para abrir o painel; use Pausar/Retomar ou Parar e salvar.
6. Os vídeos salvos serão listados na aba Gravador e também estarão na pasta Filmes/GameBoostLite.

## Limitações conhecidas e importantes

- **Áudio interno:** exige Android 10 (API 29) ou mais recente. O jogo precisa permitir a captura do áudio. Se o jogo negar captura, o vídeo pode sair sem som interno mesmo que a opção esteja selecionada.
- **Microfone:** precisa da permissão de microfone/áudio e da declaração foreground-service adequada. Em algumas situações de sistema ou fabricante, a permissão pode ser recusada.
- **Pausar/retomar:** durante a pausa, quadros e áudio são descartados; o gravador tenta manter a linha do tempo sem a duração pausada.
- **Resolução e FPS:** opções são pedidos, não promessas. O codificador do aparelho pode rejeitar certas combinações. A resolução final também não é ampliada acima da resolução natural do display.
- **Consumo de desempenho:** gravar em 1080p/60 FPS pode causar calor, uso de bateria e quedas de FPS, especialmente em aparelhos de entrada. Recomenda-se começar em 720p/30 FPS.
- **Otimizador:** esta primeira versão não altera CPU/GPU, não encerra à força processos de outros apps e não promete ganhos artificiais de FPS. Oferece informações do aparelho, atalhos de configurações e recomendações realistas.
- **Teste obrigatório:** testar em Android 10, 13, 14/15 e diferentes fabricantes. É especialmente importante verificar captura de áudio interno, rotação entre retrato/paisagem, pausas e salvamento após parar.

## Referências técnicas Android

- MediaProjection: https://developer.android.com/media/grow/media-projection
- Captura de áudio de reprodução: https://developer.android.com/media/platform/mediacapture
- Tipos de serviços em primeiro plano: https://developer.android.com/develop/background-work/services/fgs/service-types
